<?php
session_start();

// Check if user is logged in
if(!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'user'){
    header("Location: index.php");
    exit();
}

$servername="localhost";
$username="root";
$password="";
$dbname="project";

$conn=mysqli_connect($servername,$username,$password,$dbname);

// Fetch user details
$service_number = $_SESSION['user_id'];
$query = "SELECT * FROM login WHERE SVC_No = '$service_number'";
$result = mysqli_query($conn, $query);
$user = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
        }
        .user-profile {
            background-color: #f4f4f4;
            padding: 20px;
            border-radius: 8px;
        }
    </style>
</head>
<body>
    <div class="user-profile">
        <h1>User Dashboard</h1>
        <h2>Welcome, User!</h2>
        
        <h3>Your Profile</h3>
        <p><strong>Service Number:</strong> <?php echo $user['SVC_No']; ?></p>
        <p><strong>Phone Number:</strong> <?php echo $user['phone']; ?></p>
        
        <br>
        <a href="logout.php">Logout</a>
    </div>
</body>
</html>