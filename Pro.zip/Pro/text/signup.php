<?php
$servername="localhost";
$username="root";
$password="";
$dbname="project";

$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn){
    die("Connection Fail: ".mysqli_connect_error());
}
$error= $succes="";
if($_SERVER['REQUEST_METHOD']=='POST'){
    $number=$_POST['ber'];
    $tel=$_POST['tel'];
    $numb=$_POST['num'];
    $password=$_POST['pass'];
    $confirm_password=$_POST['pass1'];
    $role=$_POST['role']; // New role selection

    if($password !==$confirm_password){
        $error="Password and Confirm Password do not match";
    } else {
        // Check if service number already exists
        $query="SELECT * FROM login WHERE SVC_No='$number'";
        $result=mysqli_query($conn,$query);
        if (mysqli_num_rows($result)> 0){
            $error="Service Number Already Exists.";
         } else {
                // Hash the password
                $hashed_password=password_hash($password,PASSWORD_DEFAULT);
                
                // Insert user with role
                $inset_query="INSERT INTO login (SVC_No, phone, ID_number, password, role) 
                              VALUES ('$number', '$tel', '$numb', '$hashed_password', '$role')";
                
                if(mysqli_query($conn,$inset_query)){
                    $succes="Registration Successful. <a href='index.php'> Login Here</a>";
                } else{
                    $error="Error: ". mysqli_error($conn);
                }
            }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .main {
            background-color: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            width: 300px;
        }
        .form form {
            display: flex;
            flex-direction: column;
        }
        .form input, .form select {
            margin: 10px 0;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .btnn {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px;
            border-radius: 4px;
            cursor: pointer;
        }
        .error { color: red; }
        .success { color: green; }
    </style>
</head>
<body>
    <div class="main">
        <?php if ($error): ?>
            <p class="error"><?php echo $error; ?></p>
        <?php endif; ?>
        <?php if ($succes): ?>
            <p class="success"><?php echo $succes;?></p>
        <?php endif; ?>
        
        <div class="form">
            <form method="POST" action="">
                <h2>Create Account</h2>
                <input type="number" name="ber" placeholder="Service Number" required>
                <input type="tel" name="tel" maxlength="10" pattern="\d*" placeholder="Phone Number" required>
                <input type="number" name="num" data-maxlength="16" pattern="\d*" placeholder="ID Number" required>
                <input type="password" name="pass" placeholder="Password" required>
                <input type="password" name="pass1" placeholder="Confirm Password" required>
                
                <!-- Role Selection -->
                <select name="role" required>
                    <option value="">Select User Role</option>
                    <option value="admin">Admin</option>
                    <option value="user">Regular User</option>
                </select>
                
                <button type="submit" class="btnn">Register</button>
            </form>
            <p class="link">Already have an account?<br>
            <a href="index.php">Login</a></p>
        </div>
    </div>

    <script>
    const inputs = document.querySelectorAll('[data-maxlength]');
    inputs.forEach(input => {
        const maxLength = parseInt(input.getAttribute('data-maxlength'));
        input.addEventListener('keyup', () => {
            if (input.value.length > maxLength) {
                input.value = input.value.slice(0, maxLength);
            }
        });
    });
    </script>
</body>
</html>