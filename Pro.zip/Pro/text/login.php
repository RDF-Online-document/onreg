<?php
session_start();
$servername="localhost";
$username="root";
$password="";
$dbname="project";

$conn=mysqli_connect($servername,$username,$password,$dbname);
if(!$conn){
    die("Connection Fail: ".mysqli_connect_error());
}

$error = "";

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $service_number = $_POST['ber'];
    $password = $_POST['pass'];

    // Prepare SQL to prevent SQL injection
    $query = "SELECT * FROM login WHERE SVC_No = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "s", $service_number);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if($user = mysqli_fetch_assoc($result)){
        // Verify password
        if(password_verify($password, $user['password'])){
            // Set session variables
            $_SESSION['user_id'] = $user['SVC_No'];
            $_SESSION['user_role'] = $user['role'];

            // Redirect based on role
            if($user['role'] == 'admin'){
                header("Location: admin_dashboard.php");
                exit();
            } else {
                header("Location: user_dashboard.php");
                exit();
            }
        } else {
            $error = "Invalid password";
        }
    } else {
        $error = "No user found with this service number";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .login-container {
            background-color: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            width: 300px;
        }
        .login-form {
            display: flex;
            flex-direction: column;
        }
        .login-form input {
            margin: 10px 0;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .login-btn {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px;
            border-radius: 4px;
            cursor: pointer;
        }
        .error {
            color: red;
            text-align: center;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <?php if($error): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <form method="POST" class="login-form">
            <h2>Login</h2>
            <input type="number" name="ber" placeholder="Service Number" required>
            <input type="password" name="pass" placeholder="Password" required>
            <button type="submit" class="login-btn">Login</button>
            
            <p>Don't have an account? <a href="signup.php">Register</a></p>
        </form>
    </div>
</body>
</html>