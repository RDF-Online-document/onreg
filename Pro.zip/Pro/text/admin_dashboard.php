<?php
session_start();

// Check if user is logged in and is an admin
if(!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin'){
    header("Location: index.php");
    exit();
}
$servername="localhost";
$username="root";
$password="";
$dbname="project";

$conn=mysqli_connect($servername,$username,$password,$dbname);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        .admin-panel {
            background-color: #f4f4f4;
            padding: 20px;
            border-radius: 8px;
        }
    </style>
</head>
<body>
    <div class="admin-panel">
        <h1>Admin Dashboard</h1>
        <p>Welcome, Admin! You have full access to the system.</p>
        
        <h2>System Users</h2>
        <table border="1">
            <tr>
                <th>Service Number</th>
                <th>Phone</th>
                <th>Role</th>
            </tr>
            <?php
            $query = "SELECT SVC_No, phone, role FROM login";
            $result = mysqli_query($conn, $query);
            while($row = mysqli_fetch_assoc($result)){
                echo "<tr>";
                echo "<td>".$row['SVC_No']."</td>";
                echo "<td>".$row['phone']."</td>";
                echo "<td>".$row['role']."</td>";
                echo "</tr>";
            }
            ?>
        </table>
        
        <br>
        <a href="logout.php">Logout</a>
    </div>
</body>
</html>