<form method="post">
        <label style="margin-left:300px;">Search:</label>
        <input type="text" name="search">
        <input type="submit" name="submit">
    </form>

<?php


if (isset($_POST['submit'])) {
    $lastmission = $_POST['search'];
    $svc_no=$_POST['search'];
    $rank=$_POST['search'];
    $firstname=$_POST['search'];
    $lastname=$_POST['search'];
    $Dob=$_POST['search'];
    $responsibilities=$_POST['search'];
    $matialstatus=$_POST['search'];
    $gender=$_POST['search'];
    $deployment=$_POST['search'];
    $course=$_POST['search'];

    $regment=$_POST['search'];
    $created_at=$_POST['search'];
    // Use a prepared statement with bound parameters to prevent SQL injection
    $sql ="SELECT * FROM  our_project WHERE svc_no='$svc_no' and regment='information system'or  
    rank='$rank' and regment='information system'or
    firstname='$firstname' and regment='information system'or 
    lastname='$lastname' and regment='information system'or
    Dob='$Dob'    and regment='information system'or
    matialstatus='$matialstatus'  and regment='information system'or
    gender='$gender' and regment='information system'or
    deployment='$deployment' and regment='information system'or
    course='$course' and regment='information system'or
    created_at='$created_at'and regment='information system'";
   $result=mysqli_query($conn,$sql);
}
?>